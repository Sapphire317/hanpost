package com.example.dannyseo.hanpost;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;
import java.util.ArrayList;

public class FavoriteFragment extends Fragment {

    View v;

    RecyclerView mRecyclerView;
    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference mRef;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.fragment_favorites, container, false);

       //RecyclerView
        mRecyclerView = v.findViewById(R.id.recyclerViewFav);
        mRecyclerView.setHasFixedSize(true);

        //set layout as LinearLayout
        mRecyclerView.setLayoutManager(new LinearLayoutManager(v.getContext()));

        //send Query to FirebaseDatabase
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mRef = mFirebaseDatabase.getReference("Data");


        return v;
    }


    @Override
    public void onStart() {
        super.onStart();


        FirebaseRecyclerOptions<Model> options = new FirebaseRecyclerOptions.Builder<Model>()
                .setQuery(mRef, Model.class)
                .build();

      FirebaseRecyclerAdapter<Model, ViewHolder> firebaseRecyclerAdapter =
              new FirebaseRecyclerAdapter<Model, ViewHolder>(options) {
                  @Override
                  protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull Model model) {
                        holder.setDetails(v.getContext(), model.getTitle(), model.getDescription(), model.getDescription());
                  }

                  @NonNull
                  @Override
                  public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                      return null;
                  }
              };

      mRecyclerView.setAdapter(firebaseRecyclerAdapter);
    }
}

