package com.example.dannyseo.hanpost;

public class Model {

    String title, image, description;

    //constructor

    public Model(){}

    //getter and setters = command + N


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
